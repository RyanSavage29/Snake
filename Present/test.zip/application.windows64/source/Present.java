import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Present extends PApplet {

 Snake snake;

PImage[] tile;
int levelCheck = 1;
float speed = 1;

public void setup()
{
  
  background(0);
  
  loadTiles();
  
  //Creates and places all the menus as hidden and off
  setMenus();
  
  //Creates a new save file for High Scores if one doesn't already exist
  checkSave();
  if (!checkSave())
  {
    createSave();
  }
  
  /* Not needed yet until progression is completed
  
  checkProgression();
  if (!checkProgression())
  {
    createProgression();
  }
  */
  
  /*
  for (int j = 1, i = 0; i < worldSize; j++, i++)
  {
    worlds.add(new World(j, false));
  }
  */
  
  snake = new Snake(0, 0, false, false, false, true);
}

public void draw()
{
  if (mainMenu == true)
  {
    background(0);
    mainMenu();
  }
  
  else if (highScores == true)
  {
    background(50);
    highScores();
  }
  
  else if (creditsMenu == true)
  {
    background(100);
    creditsMenu();
  }
  
  else if (levelSelectMenu == true)
  {
    background(150);
    levelSelectMenu();
  }
  
  else if (gameStart == true)
  {
    background(250);
    gameStart();
  }
  
  else if (restartMenu == true)
  {
    background(200);
    restartMenu();
  }
  
  else if (pauseMenu == true)
  {
    background(250);
    pauseMenu();
  }
  else if (game == true)
  {
    background(250);
    runGame();
  }
}
/*
What should the snake eat?
Main Item: Cheese
Other Items: a cat (kelly), a dragon (emily), a jigglepoof (me), a kirby hat (frosty), a bug (alina), pink moa (cat), fidget spinner (miguel), tardis (ian), piece of shit with mickey mouse ears (jacob)

What should the levels be?
Final level will be a jigglepoof
Instead of finding an egg, there will be score caps for some levels or finding X amount of items

What should the snake be?
Totoro

How should the snake grow?
Small totoros

Level names will be memes and group jokes?
Kinda Snowy
Sand Guardian
Pink Moa Squad
Deatha vs Idenifi
Shy Guy
Mario Kart
SPEEEEEED
YuGiNo
Pidgeon Dating Game

Different snake for every level?

Songs?

Credits Seqeunce to go over all of the art assets to see what they represent and people who worked on it

Idenfi level and when she grabs the item, she gets a plushie gryffon follower, make the level a cube for asura homeland

Deatha's Revenge
Add 2 level specific jokes in, cookie and a cage at guild wars

Additional captues will appear twice as likely

save high scores for each level

quotes based on score

pokemon with rowlet, maud the cat?

dab animation upon hitting a high score
*/
public void keyPressed()
{
  
}

public void keyReleased()
{
  if (key == CODED)
  {
    if (keyCode == UP && game == true)
    {
      direction(1);
    }
    
    if (keyCode == DOWN && game == true)
    {
      direction(2);
    }
    
    if (keyCode == LEFT && game == true)
    {
      direction(3);
    }
    
    if (keyCode == RIGHT && game == true)
    {
      direction(4);
    }
    
    if (keyCode == UP || keyCode == DOWN || keyCode == RIGHT || keyCode == LEFT && gameStart == true)
    {
      resetMenus();
      game = true;
    }
    
    
  }
}
int[][] level;
int tileWidth = 50;
int tileHeight = tileWidth;

int[][] level1Grid = 
  //0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17
{ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 0
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 1
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 2
  { 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 3
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 4
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 5
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 6
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 7
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 8
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 9
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //10
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //11
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //12
  { 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //13
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //14
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //15
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //16
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0} }; //17
  
int[][] level2Grid = 
  //0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17
{ { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, // 0
  { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, // 1
  { 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1}, // 2
  { 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1}, // 3
  { 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1}, // 4
  { 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1}, // 5
  { 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1}, // 6
  { 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1}, // 7
  { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, // 8
  { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, // 9
  { 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1}, //10
  { 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1}, //11
  { 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1}, //12
  { 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1}, //13
  { 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1}, //14
  { 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1}, //15
  { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, //16
  { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1} }; //17

public void renderGrid()
{
  for (int row = 0, tileRow = 0; row <= 17; row++, tileRow++)
  {
    for (int col = 0, tileCol = 0; col <= 17; col++, tileCol++)
    {   
      image(tile[level[col][row]], tileRow*tileWidth, tileCol*tileHeight);
    }
  }
}

public void loadTiles()
{
  tile = new PImage[3];
  
  for (int i = 0; i < tile.length; i++)
  {
    tile[i] = loadImage(dataPath("Tiles/" + i + ".png"));
  }
}

public void currentLevel()
{
  switch(levelCheck)
  {
    case 1:
    level = level1Grid;
    setPosition1();
    break;
    
    case 2:
    level = level2Grid;
    setPosition2();
    break;
  }
}

public void runGame()
{
  renderGrid();
  renderSnake();
  update(speed);
}


ControlP5 gui;
controlP5.Button toMain, toPlay, toCredits, toScores, toQuit, playLevel, backToMain, resume, restart, selectLeft, selectRight, speed1, speed2, speed3;

/*
playLevel, resume, restart, selectRight, selectLeft, speed1, speed2, and speed3 all will have different effects other than menus

Main Menu \ \
Play \
Credits \
High Score \
Quit \ \ \
Play Level \
Back (to Main Menu) \ \ \
Resume \
Restart \
*/

boolean mainMenu = true;
boolean levelSelectMenu, gameStart, pauseMenu, restartMenu, highScores, creditsMenu, game = false;

public void mainMenu()
{
  toPlay
    .setPosition(width/2 - 150, 450)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toCredits
    .setPosition(width/2 - 150, 550)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toScores
    .setPosition(width/2 - 150, 650)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toQuit
    .setPosition(width/2 - 150, 750)
    .setSize(300, 75)
    .show()
    .setOn();
}

public void levelSelectMenu()
{
  playLevel
    .setPosition(width/2 - 150, 100)
    .setSize(300, 75)
    .show()
    .setOn();
    
  if (levelCheck > 1)
  {
    selectLeft
      .setPosition(100, 450)
      .setSize(50, 75)
      .show()
      .setOn();
  }
    
  if (levelCheck < 2)
  {
    selectRight
      .setPosition(800, 450)
      .setSize(50, 75)
      .show()
      .setOn();
  }
  
  speed1
    .setPosition(width/5 - 50, 750)
    .setSize(100, 100)
    .show()
    .setOn();
    
  speed2
    .setPosition(width/2 - 50, 750)
    .setSize(100, 100)
    .show()
    .setOn();
    
  speed3
    .setPosition(width - (width/5) - 50, 750)
    .setSize(100, 100)
    .show()
    .setOn();
}

public void gameStart()
{
  
}

public void pauseMenu()
{
  resume
    .setPosition(width/2 - 150, 250)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toMain
    .setPosition(width/2 - 150, 500)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toQuit
    .setPosition(width/2 - 150, 750)
    .setSize(300, 75)
    .show()
    .setOn();
}

public void restartMenu()
{
  restart
    .setPosition(width/2 - 150, 250)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toMain
    .setPosition(width/2 - 150, 500)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toQuit
    .setPosition(width/2 - 150, 750)
    .setSize(300, 75)
    .show()
    .setOn();
}

//Sets and Turns On the Button to Return to Main Menu
//Prints the High Scores onto the Screen
public void highScores()
{
  backToMain
    .setPosition(width/2 - 150, 750)
    .setSize(300, 75)
    .show()
    .setOn();
    
    printHighScores();
}

public void creditsMenu()
{
  backToMain
    .setPosition(width/2 - 150, 450)
    .setSize(300, 75)
    .show()
    .setOn();
}
 
public void setMenus()
{
  gui = new ControlP5(this);
  
  createMenus();
  createLevelSelect();
}

public void controlEvent(ControlEvent theEvent) 
{
  switch (theEvent.getId())
  {
   //To Main Menu
   case 1:
   resetMenus();
   mainMenu = true;
   break;
   
   //To Level Select
   case 2:
   resetMenus();
   levelSelectMenu = true;
   break;
   
   //To Game Start
   case 3:
   resetMenus();
   gameStart = true;
   break;
   
   //To Pause
   case 4:
   resetMenus();
   pauseMenu = true;
   break;
   
   //To Restart
   case 5:
   resetMenus();
   restartMenu = true;
   break;
   
   //To High Scores
   case 6:
   resetMenus();
   highScores = true;
   break;
   
   //To Credits
   case 7:
   resetMenus();
   creditsMenu = true;
   break;
   
   //Quit
   case 8:
   exit();
   break;
   
   //Resume
   case 9:
   
   break;
   
   //Restart
   case 10:
   resetMenus();
   gameStart = true;
   break;
   
   //Check Levels to the Left
   case 11:
   levelCheck -= 1;
   break;
   
   //Check Levels to the Right
   case 12:
   levelCheck += 1;
   break;
   
   //Slowest Speed
   case 13:
   speed = .5f;
   break;
   
   //Middle Speed
   case 14:
   speed = 1;
   break;
   
   //Fastest Speed
   case 15:
   speed = 1.5f;
   break;
   
   //Play Level
   case 16:
   resetMenus();
   currentLevel();
   gameStart = true;
   break;
  }
 hideMenus();
}

public void createMenus()
{
  toMain = gui.addButton("Main Menu")
    .hide()
    .setOff()
    .setId(1)
    .activateBy(ControlP5.RELEASE);
    
  toPlay = gui.addButton("Play")
    .hide()
    .setOff()
    .setId(2)
    .activateBy(ControlP5.RELEASE);

  toCredits = gui.addButton("High Scores")
    .hide()
    .setOff()
    .setId(6)
    .activateBy(ControlP5.RELEASE);
    
  toScores = gui.addButton("Credits")
    .hide()
    .setOff()
    .setId(7)
    .activateBy(ControlP5.RELEASE);
    
  toQuit = gui.addButton("Quit")
    .hide()
    .setOff()
    .setId(8)
    .activateBy(ControlP5.RELEASE);
    
  backToMain = gui.addButton("Back")
    .hide()
    .setOff()
    .setId(1)
    .activateBy(ControlP5.RELEASE);
    
  resume = gui.addButton("Resume")
    .hide()
    .setOff()
    .setId(9)
    .activateBy(ControlP5.RELEASE);
      
  restart = gui.addButton("Restart")
    .hide()
    .setOff()
    .setId(10)
    .activateBy(ControlP5.RELEASE);
}

public void createLevelSelect()
{
  playLevel = gui.addButton("Play Level")
    .hide()
    .setOff()
    .setId(16)
    .activateBy(ControlP5.RELEASE);
  
  selectLeft = gui.addButton("")
    .hide()
    .setOff()
    .setId(11)
    .activateBy(ControlP5.RELEASE);
  
  selectRight = gui.addButton(" ")
    .hide()
    .setOff()
    .setId(12)
    .activateBy(ControlP5.RELEASE);
  
  speed1 = gui.addButton("1")
    .hide()
    .setOff()
    .setId(13)
    .activateBy(ControlP5.RELEASE);
  
  speed2 = gui.addButton("2")
    .hide()
    .setOff()
    .setId(14)
    .activateBy(ControlP5.RELEASE);
  
  speed3 = gui.addButton("3")
    .hide()
    .setOff()
    .setId(15)
    .activateBy(ControlP5.RELEASE);
}

public void hideMenus()
{
  toMain
    .hide()
    .setOff();
    
  toPlay
    .hide()
    .setOff();
  
  toCredits
    .hide()
    .setOff();
    
  toScores
    .hide()
    .setOff();
    
  toQuit
    .hide()
    .setOff();
    
  playLevel
    .hide()
    .setOff();
    
  backToMain
    .hide()
    .setOff();
    
  resume
    .hide()
    .setOff();
    
  restart
    .hide()
    .setOff();
    
  selectLeft
    .hide()
    .setOff();
    
  selectRight
    .hide()
    .setOff();
    
  speed1
    .hide()
    .setOff();
    
  speed2
    .hide()
    .setOff();
    
  speed3
    .hide()
    .setOff();
}

public void resetMenus()
{
  mainMenu = false;
  levelSelectMenu = false;
  gameStart = false;
  pauseMenu = false;
  restartMenu = false;
  highScores = false;
  creditsMenu = false;
}

PrintWriter scores, progression;
Table table;
boolean saveExists, progressionExists = false;
File f;
int newScore;

//Creates a new High Score save file in csv file type with scores of 0 and current date
public void createSave()
{
  scores = createWriter(dataPath("Scores.csv"));
  scores.println("Score" + "," + "Date");
  
  for (int i = 0; i < 5; i++)
  {
    scores.println(0 + "," + month() + "/" + day() + "/" + year());
  }
  
  scores.flush();
  scores.close();
}

/* Not needed yet until progression is completed

void createProgression()
{
  progression = createWriter(dataPath("Progression.csv"));
  progression.println("0");
  
  progression.flush();
  progression.close();
}
*/

//Returns true if a High Score Save file already exists 
public boolean checkSave()
{
  f = new File(dataPath("Scores.csv"));
  if (f.exists())
  {
    saveExists = true;
  }
  return saveExists;
}

/* Not needed yet until progression is completed

void checkProgression()
{
  f = new File(dataPath("Progression.csv"));
  if (f.exists())
  {
    progressionExists = true;
  }
}
*/

//Updates the High Scores when the player achieves a High Score by adding, sorting, and then removing the lowest High Score, cannot go past 5 High Scores
public void updateScores()
{
  newScore = PApplet.parseInt(random(20)); //temp, remove when game is completed
  loadSave();
  
  TableRow row = table.addRow();
  row.setInt("Score", newScore);
  row.setString("Date", month() + "/" + day() + "/" + year());
  
  table.sortReverse("Score");
  
  if (table.getRowCount() > 5)
  {
    for (int i = table.getRowCount(); i > 5; i--)
    {
      table.removeRow(i - 1);
    }
  }
  
  saveTable(table, "Data/Scores.csv");
}

//Loads the High Scores into a table
public void loadSave()
{
  table = loadTable("Scores.csv", "header");
  
  table.setColumnType("Score", Table.INT);
}

//Prints the High Scores onto the Screen
public void printHighScores()
{
  loadSave();
  
  textSize(26);
  
  text("High Scores", width/3, 50);
  text("Date", 600, 50);
  
  for (int i = 0; i < 5; i++)
  {
    TableRow row = table.getRow(i);
    text(row.getInt("Score"), width/3, 125 + (i * 125));
    text(row.getString("Date"), 600, 125 + (i * 125));
  }
}
class Snake
{
  float x, y;
  boolean north, south, west, east;
  
  Snake(float x, float y, boolean north, boolean south, boolean west, boolean east)
  {
    this.x = x;
    this.y = y;
    this.north = north;
    this.south = south;
    this.west = west;
    this.east = east;
  }
}

public void update(float speed)
{
  if (snake.north == true)
  {
    snake.y -= speed;
  }
  
  if (snake.south == true)
  {
    snake.y += speed;
  }

  if (snake.west == true)
  {
    snake.x -= speed;
  }
  
  if (snake.east == true)
  {
    snake.x += speed;
  }
}

public void display()
{
  
}

public void death()
{
  
}

public void direction(int num)
{
  switch (num)
  {
    case 1:
    resetDirections();
    snake.north = true;
    break;
    
    case 2:
    resetDirections();
    snake.south = true;
    break;
    
    case 3:
    resetDirections();
    snake.west = true;
    break;
    
    case 4:
    resetDirections();
    snake.east = true;
    break;
  }
}

public void renderSnake()
{
  image(tile[2], snake.x, snake.y);
}

public void setPosition1()
{
  
}

public void setPosition2()
{
  snake.x = 1*50;
  snake.y = 9*50;
}

public void resetDirections()
{
  snake.north = false;
  snake.south = false;
  snake.east = false;
  snake.west = false;
}

  public void settings() {  size(900, 900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Present" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
