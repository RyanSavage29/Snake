import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Present extends PApplet {

Snake snek;

float speed = 5;

public void setup()
{
  //900 x 900 pixel canvas
  
  
  //Loads all of the tiles into an array
  loadTiles();
  
  //Loads all of the food and special sprites into an array
  loadFood();
  
  //Loads all of the backgrounds into an array
  loadBackground();
  
  //Creates and sets all the menus as hidden and off
  setMenus();
  
  //Creates a new save file for High Scores if one doesn't already exist
  checkSave();
  if (!checkSave())
  {
    createSave();
  }
  
  /* Not needed yet until progression is completed
  
  checkProgression();
  if (!checkProgression())
  {
    createProgression();
  }
  */
  //Creates all of the audio
  createAudio();
  
  snek = new Snake();
  
  mainMusic.loop();
}

public void draw()
{
  background(0);
  gameState();
}

public void gameState()
{
  if (mainMenu == true)
  {
    mainMenu();
  }
  
  else if (highScores == true)
  {
    highScores();
  }
  
  else if (creditsMenu == true)
  {
    creditsMenu();
  }
  
  else if (levelSelectMenu == true)
  {
    levelSelectMenu();
  }
  
  else if (gameStart == true)
  {
    gameStart();
  }
  
  else if (restartMenu == true)
  {
    restartMenu();
  }
  
  else if (pauseMenu == true)
  {
    pauseMenu();
  }
  else if (game == true)
  {
    runGame();
    
    if (foodAnimation == 0)
    {
      foodAnimation += 1;
    }
    else
    {
      foodAnimation -= 1;
    }
  }
}

public void runGame()
{
  //println(temp1);
  frameRate(speed);
  renderGrid();
  
  checkSpecial();
  
  if (specialCheck)
  {
    pickSpecial(temp1, levelCheck);
    eatSpecial(special, snek.x, snek.y);
  }
  
  if (eatFood(food, snek.x, snek.y))
  {
    setFood(PApplet.parseInt(random(29)), PApplet.parseInt(random(29)));
  }
  
  image(cheese[foodAnimation], food.x, food.y);
  
  snek.update();
  snek.display();
  snek.death();
}
PImage[] cheese, dragon, cat, bug, jigglepoof, shit, coffee, kirby, moa, tardis, fidget;
PImage[] acorn, fuzzy, cookie, cage;
int temp1, temp2, tempCheck = -1;
int foodAnimation = 1;

public void loadFood()
{
  cheese = new PImage[2];
  
  for (int i = 0; i < cheese.length; i++)
  {
    cheese[i] = loadImage(dataPath("Food/cheese" + i + ".png"));
  }
  
  dragon = new PImage[2];
  
  for (int i = 0; i < dragon.length; i++)
  {
    dragon[i] = loadImage(dataPath("Food/dragon" + i + ".png"));
  }
  
  cat = new PImage[2];
  
  for (int i = 0; i < cat.length; i++)
  {
    cat[i] = loadImage(dataPath("Food/cat" + i + ".png"));
  }
  
  bug = new PImage[2];
  
  for (int i = 0; i < bug.length; i++)
  {
    bug[i] = loadImage(dataPath("Food/bug" + i + ".png"));
  }
  /*
  jigglepoof = new PImage[2];
  
  for (int i = 0; i < jigglepoof.length; i++)
  {
    jigglepoof[i] = loadImage(dataPath("Food/jigglepoof" + i + ".png"));
  }
  */
  shit = new PImage[2];
  
  for (int i = 0; i < shit.length; i++)
  {
    shit[i] = loadImage(dataPath("Food/shit" + i + ".png"));
  }
  
  
  coffee = new PImage[2];
  
  for (int i = 0; i < coffee.length; i++)
  {
    coffee[i] = loadImage(dataPath("Food/coffee" + i + ".png"));
  }
  
  kirby = new PImage[2];
  
  for (int i = 0; i < kirby.length; i++)
  {
    kirby[i] = loadImage(dataPath("Food/kirby" + i + ".png"));
  }
  
  moa = new PImage[2];
  
  for (int i = 0; i < moa.length; i++)
  {
    moa[i] = loadImage(dataPath("Food/moa" + i + ".png"));
  }
  
  tardis = new PImage[2];
  
  for (int i = 0; i < tardis.length; i++)
  {
    tardis[i] = loadImage(dataPath("Food/tardis" + i + ".png"));
  }
  
  fidget = new PImage[2];
  
  for (int i = 0; i < fidget.length; i++)
  {
    fidget[i] = loadImage(dataPath("Food/fidget" + i + ".png"));
  }
  
  acorn = new PImage[2];
  
  for (int i = 0; i < acorn.length; i++)
  {
    acorn[i] = loadImage(dataPath("Food/acorn" + i + ".png"));
  }
  
  fuzzy = new PImage[2];
  
  for (int i = 0; i < acorn.length; i++)
  {
    fuzzy[i] = loadImage(dataPath("Food/fuzzy" + i + ".png"));
  }
  
  cookie = new PImage[2];
  
  for (int i = 0; i < cookie.length; i++)
  {
    cookie[i] = loadImage(dataPath("Food/cookie" + i + ".png"));
  }
  
  cage = new PImage[2];
  
  for (int i = 0; i < cage.length; i++)
  {
    cage[i] = loadImage(dataPath("Food/cage" + i + ".png"));
  }
  
}

public void pickSpecial(int num, int levelCheck)
{
  switch (levelCheck)
  {
    case 1:
    totoroSpecial(num);
    break;
    
    case 2:
    guildWarsSpecial(num);
    break;
  }
}

public void totoroSpecial(int num)
{
  switch (num)
  {
    case 10:
    image(acorn[foodAnimation], special.x, special.y);
    break;
    
    case 11:
    image(fuzzy[foodAnimation], special.x, special.y);
    break;
    
    default:
    regularSpecial(num);
    break;
  }
}

public void guildWarsSpecial(int num)
{
  switch (num)
  {
    case 10:
    image(cookie[foodAnimation], special.x, special.y);
    break;
    
    case 11:
    image(cage[foodAnimation], special.x, special.y);
    break;
    
    default:
    regularSpecial(num);
    break;
  }
}

public void regularSpecial(int num)
{
  switch (num)
  {
    case 0:
    image(dragon[foodAnimation], special.x, special.y);
    break;
    
    case 1:
    image(cat[foodAnimation], special.x, special.y);
    break;
    
    case 2:
    image(bug[foodAnimation], special.x, special.y);
    break;
    
    case 3:
    image(jigglepoof[foodAnimation], special.x, special.y);
    break;
    
    case 4:
    image(shit[foodAnimation], special.x, special.y);
    break;
    
    case 5:
    image(coffee[foodAnimation], special.x, special.y);
    break;
    
    case 6:
    image(kirby[foodAnimation], special.x, special.y);
    break;
    
    case 7:
    image(moa[foodAnimation], special.x, special.y);
    break;
    
    case 8:
    image(tardis[foodAnimation], special.x, special.y);
    break;
    
    case 9:
    image(fidget[foodAnimation], special.x, special.y);
    break;
  }
}

public void displayHead(float x, float y)
{
  if ((direction == 1 && previousDirection == 3) || (direction == 3 && previousDirection == 1))
  {
    image(tile[6], x, y);
  }
  
  else if ((direction == 1 && previousDirection == 4) || (direction == 4 && previousDirection == 1))
  {
    image(tile[7], x, y);
  }
  
  else if ((direction == 2 && previousDirection == 3) || (direction == 3 && previousDirection == 2))
  {
    image(tile[5], x, y);
  }
  
  else if ((direction == 2 && previousDirection == 4) || (direction == 4 && previousDirection == 2))
  {
    image(tile[4], x, y);
  }
}

public void displayTail(float x, float y, float z, float w)
{
  if ((w == 1 && z == 3) || (w == 3 && z == 1))
  {
    //image(tile[12], x, y);
    image(tile[6], x, y);
  }
  
 else if ((w == 1 && z == 4) || (w == 4 && z == 1))
  {
    //image(tile[11], x, y);
    image(tile[7], x, y);
  }
  
  else if ((w == 2 && z == 3) || (w == 3 && z == 2))
  {
    //image(tile[10], x, y);
    image(tile[5], x, y);
  }
  
  else if ((w == 2 && z == 4) || (w == 4 && z == 2))
  {
    //image(tile[3], x, y);
    image(tile[4], x, y);
  }
}

public void tempRandom()
{
  temp1 = PApplet.parseInt(random(12));
  
  if (temp1 == 3)
  {
    tempRandom();
  }
  
  if (tempCheck == temp1)
  {
    tempRandom();
  }
  
  tempCheck = temp1;
}
PVector food, special;
int specialTotal = 1, randSpecial, pickSpecial, tempTotal;
boolean tailCheck, specialCheck = false;

//Places the food on a tile that doesn't have collision
public void setFood(int row, int col)
{
  for (PVector v : snek.tail) 
    {
      if (col == v.x/scale && row == v.y/scale)
      {
        tailCheck = true;
        break;
      }
      else
      {
        tailCheck = false;
      }
    }
    
  //need to rework this so that food doesn't change the grid tiles, only builds a food object over it
  if (level[col][row] == 1 && tailCheck == false && !specialCheck)
  {
    food = new PVector(row, col);
    food.mult(scale);
  }
  
  else if (specialCheck)
  {
    if (level[row][col] == 1 && tailCheck == false && !(row == special.x && col == special.y))
    {
      food = new PVector(row, col);
      food.mult(scale);
    }
  }
  
  else
  {
    row = PApplet.parseInt(random(29));
    col = PApplet.parseInt(random(29));
    setFood(row, col);
  }
}

public void setSpecial(int row, int col)
{
  for (PVector v : snek.tail) 
    {
      if (col == v.x/scale && row == v.y/scale)
      {
        tailCheck = true;
        break;
      }
      else
      {
        tailCheck = false;
      }
    }
    
  //need to rework this so that food doesn't change the grid tiles, only builds a food object over it
  if (level[row][col] == 1 && tailCheck == false && !(row == food.x && col == food.y))
  {
    special = new PVector(row, col);
    special.mult(scale);
  }
  
  else
  {
    row = PApplet.parseInt(random(29));
    col = PApplet.parseInt(random(29));
    setSpecial(row, col);
  }
}

//Checks to see if snake ate the food
public boolean eatFood(PVector pos, float snekX, float snekY)
{
  float d = dist(snekX, snekY, pos.x, pos.y);
  
    if (d < 1) 
    {
      snek.total++;
      tempTotal = PApplet.parseInt(snek.total);
      newScore += levelCheck * speed;
      return true;
    } 
    return false;
}

public void eatSpecial(PVector pos, float snekX, float snekY)
{
  float d = dist(snekX, snekY, pos.x, pos.y);
  
  if (d < 1)
  {
    snek.total++;
    newScore += (levelCheck * speed) + (specialTotal * speed);
    specialTotal++;
    specialCheck = false;
  }
}

public void checkSpecial()
{
  //if ((randSpecial * specialTotal == int(snek.total)) & !specialCheck)
  if ((tempTotal == PApplet.parseInt(snek.total)) && !specialCheck)
  {
    pickSpecial = PApplet.parseInt(random(2));
    setSpecial(PApplet.parseInt(random(29)), PApplet.parseInt(random(29)));
    tempRandom();
    specialCheck = true;
  }
}
/*
What should the snake eat?
Main Item: Cheese
Other Items: a cat (kelly), a dragon (emily), a jigglepoof (me), a kirby hat (frosty), a bug (alina), pink moa (cat), fidget spinner (miguel), tardis (ian), piece of shit with mickey mouse ears (jacob)

What should the levels be?
Final level will be a jigglepoof
Instead of finding an egg, there will be score caps for some levels or finding X amount of items

What should the snake be?
Totoro

How should the snake grow?
Small totoros

Level names will be memes and group jokes?
Kinda Snowy
Sand Guardian
Pink Moa Squad
Deatha vs Idenifi
Shy Guy
Mario Kart
SPEEEEEED
YuGiNo
Pidgeon Dating Game

Different snake for every level?

Songs?

Credits Seqeunce to go over all of the art assets to see what they represent and people who worked on it

Idenfi level and when she grabs the item, she gets a plushie gryffon follower, make the level a cube for asura homeland

Deatha's Revenge
Add 2 level specific jokes in, cookie and a cage at guild wars

Additional captues will appear twice as likely

save high scores for each level

quotes based on score

pokemon with rowlet, maud the cat?

dab animation upon hitting a high score

rwby level
*/
boolean turn = false;

int previousDirection, direction;

public void keyPressed()
{
  if (key == CODED)
  {
    if (game == true && !turn)
    {
      if (keyCode == UP && snek.north == false && snek.south == false)
      {
        previousDirection = direction;
        snek.direction(1);
      }
    
      if (keyCode == DOWN && snek.south == false && snek.north == false)
      {
        previousDirection = direction;
        snek.direction(2);
      }
    
      if (keyCode == LEFT && snek.west == false && snek.east == false)
      {
        previousDirection = direction;
        snek.direction(3);
      }
    
      if (keyCode == RIGHT && snek.east == false && snek.west == false)
      {
        previousDirection = direction;
        snek.direction(4);
      }
    }
    
    
    if ((keyCode == UP || keyCode == DOWN || keyCode == RIGHT || keyCode == LEFT) && gameStart == true)
    {
      resetMenus();
      game = true;
      playLevelMusic();
    }
  }
}
/* Class that creates all of the level grids. creating the tiles for the levels, and selecting the level */

PImage[] tile;
int[][] level;
int scale = 30;
int levelCheck = 1;

//Totoro Level
int[][] level1Grid = 
  //0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28.29
{ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 0
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 1
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 2
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 3
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 4
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 5
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 6
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 7
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 8
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 9
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //10
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //11
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //12
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //13
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //14
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //15
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //16
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //17
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //18
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //19
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //20
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //21
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //22
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //23
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //24
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //25
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //26
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //27
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //28
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0} }; //29
  
//Guild Wars 2 Level
int[][] level2Grid = 
  //0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29
{ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 0
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 1
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 2
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 3
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 4
  { 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0}, // 5
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, // 6
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, // 7
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, // 8
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, // 9
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, //10
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, //11
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //12
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //13
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //14
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //15
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //16
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //17
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, //18
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, //19
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, //20
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, //21
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, //22
  { 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0}, //23
  { 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0}, //24
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //25
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //26
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //27
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //28
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0} }; //29

int[][] level3Grid = 
  //0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28.29
{ { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 0
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, // 1
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 2
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 3
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 4
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 5
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 6
  { 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0}, // 7
  { 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0}, // 8
  { 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0}, // 9
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //10
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //11
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //12
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //13
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //14
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //15
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //16
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //17
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //18
  { 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //19
  { 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0}, //20
  { 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0}, //21
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //22
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //23
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //24
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //25
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //26
  { 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0}, //27
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //28
  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0} }; //29
  
//Displays the level based on the grid  
public void renderGrid()
{
  for (int row = 0, tileRow = 0; row <= scale - 1; row++, tileRow++)
  {
    for (int col = 0, tileCol = 0; col <= scale - 1; col++, tileCol++)
    {   
      image(tile[level[col][row]], tileRow*scale, tileCol*scale);
    }
  }
  
  text("Score: " + newScore, scale, scale);
}

//Loads all of the tiles into an array
public void loadTiles()
{
  tile = new PImage[13];
  
  for (int i = 0; i < tile.length; i++)
  {
    tile[i] = loadImage(dataPath("Tiles/" + i + ".png"));
  }
}

//Checks to see what the current level is and sets that level
public void currentLevel()
{
  switch(levelCheck)
  {
    case 1:
    level = level1Grid;
    snek.setPosition1();
    randSpecial = PApplet.parseInt(random(8, 12));
    break;
    
    case 2:
    level = level2Grid;
    snek.setPosition2();
    randSpecial = PApplet.parseInt(random(8, 12));
    break;
  }
}


ControlP5 gui;
controlP5.Button toMain, toPlay, toCredits, toScores, toQuit, playLevel, backToMain, resume, restart, selectLeft, selectRight, speed1, speed2, speed3;

PImage[] backgroundImage;

/*
playLevel, resume, restart, selectRight, selectLeft, speed1, speed2, and speed3 all will have different effects other than menus

Main Menu \ \
Play \
Credits \
High Score \
Quit \ \ \
Play Level \
Back (to Main Menu) \ \ \
Resume \
Restart \
*/

boolean mainMenu = true;
boolean levelSelectMenu, gameStart, pauseMenu, restartMenu, highScores, creditsMenu, game = false;

public void loadBackground()
{
  backgroundImage = new PImage[5];
  
  backgroundImage[0] = loadImage("Background/mainmenu.jpg");
  backgroundImage[1] = loadImage("Background/start.jpg");
  backgroundImage[2] = loadImage("Background/totoro.jpg");
  backgroundImage[3] = loadImage("Background/guildwars.jpg");
  backgroundImage[4] = loadImage("Background/death.jpg");
}

public void mainMenu()
{
  background(backgroundImage[0]);
  
  toPlay
    .setPosition(width/2 - 150, 450)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toCredits
    .setPosition(width/2 - 150, 550)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toScores
    .setPosition(width/2 - 150, 650)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toQuit
    .setPosition(width/2 - 150, 750)
    .setSize(300, 75)
    .show()
    .setOn();
}

public void levelSelectMenu()
{
  playLevel
    .setPosition(width/2 - 150, 100)
    .setSize(300, 75)
    .show()
    .setOn();
    
  if (levelCheck > 1)
  {
    background(backgroundImage[3]);
    
    selectLeft
      .setPosition(50, 450)
      .setSize(50, 75)
      .show()
      .setOn();
  }
    
  if (levelCheck < 2)
  {
    background(backgroundImage[2]);
    
    selectRight
      .setPosition(800, 450)
      .setSize(50, 75)
      .show()
      .setOn();
  }
  
  speed1
    .setPosition(width/5 - 50, 750)
    .setSize(100, 100)
    .show()
    .setOn();
    
  speed2
    .setPosition(width/2 - 50, 750)
    .setSize(100, 100)
    .show()
    .setOn();
    
  speed3
    .setPosition(width - (width/5) - 50, 750)
    .setSize(100, 100)
    .show()
    .setOn();
}

public void gameStart()
{
  background(backgroundImage[1]);
  
  resetMainMenuMusic();
  textSize(40);
  text("Press an arrow key to begin playing!", width/5, height/3);
}

public void pauseMenu()
{
  resume
    .setPosition(width/2 - 150, 250)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toMain
    .setPosition(width/2 - 150, 500)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toQuit
    .setPosition(width/2 - 150, 750)
    .setSize(300, 75)
    .show()
    .setOn();
}

public void restartMenu()
{
  background(backgroundImage[4]);
  
  restart
    .setPosition(width/2 - 150, 250)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toMain
    .setPosition(width/2 - 150, 500)
    .setSize(300, 75)
    .show()
    .setOn();
    
  toQuit
    .setPosition(width/2 - 150, 750)
    .setSize(300, 75)
    .show()
    .setOn();
}

//Sets and Turns On the Button to Return to Main Menu
//Prints the High Scores onto the Screen
public void highScores()
{
  backToMain
    .setPosition(width/2 - 150, 750)
    .setSize(300, 75)
    .show()
    .setOn();
    
    printHighScores();
}

public void creditsMenu()
{
  backToMain
    .setPosition(width/2 - 150, 450)
    .setSize(300, 75)
    .show()
    .setOn();
}
 
public void setMenus()
{
  gui = new ControlP5(this);
  
  createMenus();
  createLevelSelect();
}

public void controlEvent(ControlEvent theEvent) 
{
  switch (theEvent.getId())
  {
   //To Main Menu
   case 1:
   resetMenus();
   mainMenu = true;
   if (!mainMusicIsPlaying)
   {
     mainMusic.loop();
     mainMusicIsPlaying = true;
   }
   break;
   
   //To Level Select
   case 2:
   resetMenus();
   levelSelectMenu = true;
   levelCheck = 1;
   break;
   
   //To Game Start
   case 3:
   resetMenus();
   gameStart = true;
   break;
   
   //To Pause
   case 4:
   resetMenus();
   pauseMenu = true;
   break;
   
   //To Restart
   case 5:
   resetMenus();
   restartMenu = true;
   break;
   
   //To High Scores
   case 6:
   resetMenus();
   highScores = true;
   break;
   
   //To Credits
   case 7:
   resetMenus();
   resetMainMenuMusic();
   creditsMenu = true;
   creditsMusic.loop();
   break;
   
   //Quit
   case 8:
   exit();
   break;
   
   //Resume
   case 9:
   
   break;
   
   //Restart
   case 10:
   resetMenus();
   currentLevel();
   gameStart = true;
   setFood(PApplet.parseInt(random(17)), PApplet.parseInt(random(17)));
   break;
   
   //Check Levels to the Left
   case 11:
   levelCheck -= 1;
   break;
   
   //Check Levels to the Right
   case 12:
   levelCheck += 1;
   break;
   
   //Slowest Speed
   case 13:
   speed = 5;
   break;
   
   //Middle Speed
   case 14:
   speed = 7;
   break;
   
   //Fastest Speed
   case 15:
   speed = 10;
   break;
   
   //Play Level
   case 16:
   resetMenus();
   println(levelCheck);
   currentLevel();
   println(levelCheck);
   gameStart = true;
   setFood(PApplet.parseInt(random(29)), PApplet.parseInt(random(29)));
   break;
  }
 hideMenus();
}

public void createMenus()
{
  toMain = gui.addButton("Main Menu")
    .hide()
    .setOff()
    .setId(1)
    .activateBy(ControlP5.RELEASE);
    
  toPlay = gui.addButton("Play")
    .hide()
    .setOff()
    .setId(2)
    .activateBy(ControlP5.RELEASE);

  toCredits = gui.addButton("High Scores")
    .hide()
    .setOff()
    .setId(6)
    .activateBy(ControlP5.RELEASE);
    
  toScores = gui.addButton("Credits")
    .hide()
    .setOff()
    .setId(7)
    .activateBy(ControlP5.RELEASE);
    
  toQuit = gui.addButton("Quit")
    .hide()
    .setOff()
    .setId(8)
    .activateBy(ControlP5.RELEASE);
    
  backToMain = gui.addButton("Back")
    .hide()
    .setOff()
    .setId(1)
    .activateBy(ControlP5.RELEASE);
    
  resume = gui.addButton("Resume")
    .hide()
    .setOff()
    .setId(9)
    .activateBy(ControlP5.RELEASE);
      
  restart = gui.addButton("Restart")
    .hide()
    .setOff()
    .setId(10)
    .activateBy(ControlP5.RELEASE);
}

public void createLevelSelect()
{
  playLevel = gui.addButton("Play Level")
    .hide()
    .setOff()
    .setId(16)
    .activateBy(ControlP5.RELEASE);
  
  selectLeft = gui.addButton("")
    .hide()
    .setOff()
    .setId(11)
    .activateBy(ControlP5.RELEASE);
  
  selectRight = gui.addButton(" ")
    .hide()
    .setOff()
    .setId(12)
    .activateBy(ControlP5.RELEASE);
  
  speed1 = gui.addButton("1")
    .hide()
    .setOff()
    .setId(13)
    .activateBy(ControlP5.RELEASE);
  
  speed2 = gui.addButton("2")
    .hide()
    .setOff()
    .setId(14)
    .activateBy(ControlP5.RELEASE);
  
  speed3 = gui.addButton("3")
    .hide()
    .setOff()
    .setId(15)
    .activateBy(ControlP5.RELEASE);
}

public void hideMenus()
{
  toMain
    .hide()
    .setOff();
    
  toPlay
    .hide()
    .setOff();
  
  toCredits
    .hide()
    .setOff();
    
  toScores
    .hide()
    .setOff();
    
  toQuit
    .hide()
    .setOff();
    
  playLevel
    .hide()
    .setOff();
    
  backToMain
    .hide()
    .setOff();
    
  resume
    .hide()
    .setOff();
    
  restart
    .hide()
    .setOff();
    
  selectLeft
    .hide()
    .setOff();
    
  selectRight
    .hide()
    .setOff();
    
  speed1
    .hide()
    .setOff();
    
  speed2
    .hide()
    .setOff();
    
  speed3
    .hide()
    .setOff();
}

public void resetMenus()
{
  mainMenu = false;
  levelSelectMenu = false;
  gameStart = false;
  pauseMenu = false;
  restartMenu = false;
  highScores = false;
  creditsMenu = false;
  game = false;
  
  resetMusic();
}
/* Class that loads and controls all of the music */



SoundFile mainMusic, creditsMusic, restartMusic;
SoundFile[] totoro, guildWars;

boolean mainMusicIsPlaying = true;

//Loads all of the music in setup
public void createAudio()
{ 
  mainMusic = new SoundFile(this, "Music/PMD_Menu.ogg");
  creditsMusic = new SoundFile(this, "Music/Queen.ogg");
  restartMusic = new SoundFile(this, "Music/Undyne_Death.ogg");
  
  totoro = new SoundFile[3];
  
  for (int i = 0; i < totoro.length; i++)
  {
    totoro[i] = new SoundFile(this, "Music/Totoro" + i + ".ogg");
  }
  
  guildWars = new SoundFile[3];
  
  for (int i = 0; i < guildWars.length; i++)
  {
    guildWars[i] = new SoundFile(this, "Music/GuildWars" + i + ".ogg");
  }
}

//Easy to call function that stops all of the music
public void resetMusic()
{ 
  creditsMusic.stop();
  
  restartMusic.stop();
  
  for (int i = 0; i < 3; i++)
  {
    totoro[i].stop();
    
    guildWars[i].stop();
  }
}

//Easy to call function that stops main menu music
public void resetMainMenuMusic()
{
  mainMusic.stop();
  mainMusicIsPlaying = false;
}

//Plays music for each level based on what level it is
public void playLevelMusic()
{
  switch(levelCheck)
  {
    case 1:
    totoro[PApplet.parseInt(random(3))].loop();
    break;
    
    case 2:
    guildWars[PApplet.parseInt(random(3))].loop();
    break;
  }
}
/* Class that contains all of the functions for saving high scores and progression */

PrintWriter scores, progression;
Table table;
boolean saveExists, progressionExists = false;
File f;
int newScore = 0;

//Creates a new High Score save file in csv file type with scores of 0 and current date
public void createSave()
{
  scores = createWriter(dataPath("Scores.csv"));
  scores.println("Score" + "," + "Date");
  
  for (int i = 0; i < 5; i++)
  {
    scores.println(0 + "," + month() + "/" + day() + "/" + year());
  }
  
  scores.flush();
  scores.close();
}

/* Not needed yet until progression is completed

void createProgression()
{
  progression = createWriter(dataPath("Progression.csv"));
  progression.println("0");
  
  progression.flush();
  progression.close();
}
*/

//Returns true if a High Score Save file already exists 
public boolean checkSave()
{
  f = new File(dataPath("Scores.csv"));
  if (f.exists())
  {
    saveExists = true;
  }
  return saveExists;
}

/* Not needed yet until progression is completed

void checkProgression()
{
  f = new File(dataPath("Progression.csv"));
  if (f.exists())
  {
    progressionExists = true;
  }
}
*/

//Updates the High Scores when the player achieves a High Score by adding, sorting, and then removing the lowest High Score, cannot go past 5 High Scores
public void updateScores()
{
  loadSave();
  
  TableRow row = table.addRow();
  row.setInt("Score", newScore);
  row.setString("Date", month() + "/" + day() + "/" + year());
  
  table.sortReverse("Score");
  
  if (table.getRowCount() > 5)
  {
    for (int i = table.getRowCount(); i > 5; i--)
    {
      table.removeRow(i - 1);
    }
  }
  
  saveTable(table, "Data/Scores.csv");
  
  newScore = 0;
}

//Loads the High Scores into a table
public void loadSave()
{
  table = loadTable("Scores.csv", "header");
  
  table.setColumnType("Score", Table.INT);
}

//Prints the High Scores onto the Screen
public void printHighScores()
{
  loadSave();
  
  textSize(26);
  
  text("High Scores", width/3, 50);
  text("Date", 600, 50);
  
  for (int i = 0; i < 5; i++)
  {
    TableRow row = table.getRow(i);
    text(row.getInt("Score"), width/3, 125 + (i * 125));
    text(row.getString("Date"), 600, 125 + (i * 125));
  }
}
/* Class that holds all of the snake information and functions*/

class Snake
{
  float x, y, z, w, xspeed, yspeed, total;
  boolean north = false, south = false, west = false, east = false;
  ArrayList<PVector> tail = new ArrayList<PVector>();
  ArrayList<PVector> tailDirection = new ArrayList<PVector>();
  ArrayList<PVector> tailTimer = new ArrayList<PVector>();
  
  Snake()
  {
    
  }
  
  //updates the direction based on a calculation of speed using 0, 1, and -1
  public void dir(float x, float y)
  {
    if (xspeed == 1)
    {
      z = 4;
    }
    
    else if (xspeed == -1)
    {
      z = 3;
    }
    
    else if (yspeed == 1)
    {
      z = 2;
    }
    
    else if (yspeed == -1)
    {
      z = 1;
    }
    
    xspeed = x;
    yspeed = y;
    
    if (xspeed == 1)
    {
      w = 4;
    }
    
    else if (xspeed == -1)
    {
      w = 3;
    }
    
    else if (yspeed == 1)
    {
      w = 2;
    }
    
    else if (yspeed == -1)
    {
      w = 1;
    }
  }
  
  //increases the x or y position of each tail part and head based on the input of the player and previous direction
  public void update()
  {
    if (total > 0) 
    {
      if (total == tail.size() && !tail.isEmpty()) 
      {
        tail.remove(0);
        tailDirection.remove(0);
      }
      tail.add(new PVector(x, y));
      tailDirection.add(new PVector(z, w));
    }

    x = x + xspeed*scale;
    y = y + yspeed*scale;
    
    turn = false;
  }

  //displays the snake head and tail
  public void display()
  {
    for (int i = 0; i < tail.size(); i++)
    {
      displayTail(tail.get(i).x, tail.get(i).y, tailDirection.get(i).x, tailDirection.get(i).y);
    }
    
    displayHead(x, y);
  }

  //ends the game and sends it to restart menu when the snake collides with any walls or the tail
  public void death()
  {
    for (int i = 0; i < tail.size(); i++) 
    {
      PVector pos = tail.get(i);
      float d = dist(x, y, pos.x, pos.y);
      
      if (d < 1) 
      {
        updateScores();
        snakeReset();
        resetMenus();
        restartMenu = true;
        restartMusic.loop();
      }
    }
    
    if (level[PApplet.parseInt(y/scale)][PApplet.parseInt(x/scale)] == 0)
      {
        updateScores();
        snakeReset();
        resetMenus();
        restartMenu = true;
        restartMusic.loop();
      }
  }

  //updates the direction based on user input
  public void direction(int num)
  {
      switch (num)
      {
        case 1:
        resetDirections();
        north = true;
        dir(0, -1);
        direction = 1;
        break;
    
        case 2:
        resetDirections();
        south = true;
        dir(0, 1);
        direction = 2;
        break;
    
        case 3:
        resetDirections();
        west = true;
        dir(-1, 0);
        direction = 3;
        break;
    
        case 4:
        resetDirections();
        east = true;
        dir(1, 0);
        direction = 4;
        break;
      }
      
      turn = true;
  }
  
  //sets the position and direction of the snake for level 1
  public void setPosition1()
  {
    x = 3*scale;
    y = 3*scale;
    direction(4);
    direction = 4;
    previousDirection = 2;
  }

  //sets the position and direction of the snake for level 2
  public void setPosition2()
  {
    x = 2*scale;
    y = 15*scale;
    direction(4);
    direction = 4;
    previousDirection = 2;
  }

  //easy reset of direction booleans
  public void resetDirections()
  {
    snek.north = false;
    snek.south = false;
    snek.east = false;
    snek.west = false;
  }
  
  public void snakeReset()
  {
    total = 0;
    specialTotal = 1;
    specialCheck = false;
    tail.clear();
    tailDirection.clear();
  }
}
  public void settings() {  size(900, 900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Present" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
